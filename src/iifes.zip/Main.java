package iifes;

public class Main {
    public static void main(String[] args) {
        Sistema s = new Sistema();
        Entrada e = new Entrada();

        e.menu(s);
    }
}
